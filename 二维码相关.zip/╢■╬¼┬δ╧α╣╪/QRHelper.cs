﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using ZXing;
using ZXing.Common;

namespace LLH {
    public class QRHelper : MonoBehaviour {

        /// <summary>
        /// 将字符串编码成二维码，返回Texture
        /// </summary>
        /// <param name="content">内容</param>
        /// <param name="width">生成texture的宽度</param>
        /// <param name="height">生成texture的高度</param>
        public static Texture2D Encode(string content, int width, int height) {
            MultiFormatWriter writer = new MultiFormatWriter();
            Dictionary<EncodeHintType, object> hints = new Dictionary<EncodeHintType, object>();
            hints.Add(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.Add(EncodeHintType.MARGIN, 0);
            hints.Add(EncodeHintType.QR_VERSION, 4);
            BitMatrix bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, width, height, hints);

            BitMatrix newBitMatrix = UpdateBitMatrix(bitMatrix, 10);

            // 转成texture2d
            //int w = bitMatrix.Width;
            //int h = bitMatrix.Height;
            int w = newBitMatrix.Width;
            int h = newBitMatrix.Height;

            Texture2D texture = new Texture2D(w, h, TextureFormat.ARGB32, false);

            for (int x = 0; x < h; x++) {
                for (int y = 0; y < w; y++) {
                    if (newBitMatrix[x, y]) {
                        texture.SetPixel(y, x, UnityEngine.Color.black);
                    }
                    else {
                        texture.SetPixel(y, x, UnityEngine.Color.white);
                    }
                }
            }
            texture.Apply();

            //byte[] bytes = texture.EncodeToPNG();
            //File.WriteAllBytes(Application.dataPath + "/testTex.png", bytes);
            return texture;
        }

        /// <summary>
        /// 生成带有中心图标的二维码，返回Texture2D
        /// </summary>
        /// <param name="content">内容</param>
        /// <param name="width">生成Sprite的宽度</param>
        /// <param name="height">生成Sprite的高度</param>
        /// <param name="centerIcon">中心图片</param>
        public static Texture2D GenerateQRCodeWithIcon(string content, int width, int height, Texture2D centerIcon) {
            // 编码成color32
            MultiFormatWriter writer = new MultiFormatWriter();
            Dictionary<EncodeHintType, object> hints = new Dictionary<EncodeHintType, object>();
            hints.Add(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.Add(EncodeHintType.MARGIN, 0);
            hints.Add(EncodeHintType.QR_VERSION, 4);
            BitMatrix bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, width, height, hints);

            BitMatrix newBitMatrix = UpdateBitMatrix(bitMatrix, 10);

            // 转成texture2d
            int w = newBitMatrix.Width;
            int h = newBitMatrix.Height;
            Texture2D texture = new Texture2D(w, h, TextureFormat.ARGB32, false);
            for (int x = 0; x < h; x++) {
                for (int y = 0; y < w; y++) {
                    if (newBitMatrix[x, y]) {
                        texture.SetPixel(y, x, UnityEngine.Color.black);
                    }
                    else {
                        texture.SetPixel(y, x, UnityEngine.Color.white);
                    }
                }
            }

            // 添加小图
            int halfWidth = texture.width / 2;
            int halfHeight = texture.height / 2;
            int halfWidthOfIcon = centerIcon.width / 2;
            int halfHeightOfIcon = centerIcon.height / 2;
            int centerOffsetX = 0;
            int centerOffsetY = 0;
            for (int x = 0; x < h; x++) {
                for (int y = 0; y < w; y++) {
                    centerOffsetX = x - halfWidth;
                    centerOffsetY = y - halfHeight;
                    if (Mathf.Abs(centerOffsetX) <= halfWidthOfIcon && Mathf.Abs(centerOffsetY) <= halfHeightOfIcon) {
                        texture.SetPixel(x, y, centerIcon.GetPixel(centerOffsetX + halfWidthOfIcon, centerOffsetY + halfHeightOfIcon));
                    }
                }
            }
            texture.Apply();

            //Sprite sp = Sprite.Create(texture, new Rect(0, 0, w, h), Vector2.zero);
            //UnityEngine.Object.Destroy(texture);
            return texture;
        }


        /// <summary>
        /// 将字符串编码成二维码，返回Sprite
        /// </summary>
        /// <param name="content">二维码内容</param>
        /// <param name="width">生成Sprite的宽度</param>
        /// <param name="height">生成Sprite的高度</param>
        public static Sprite GetQRCode(string content, int width, int height) {
            Texture2D texture = Encode(content, width, height);
            Sprite sp = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.zero);
            return sp;
        }

        /// <summary>
        /// 生成带有中心图标的二维码，返回Sprite
        /// </summary>
        public static Sprite GetQRCodeWithIcon(string content, int width, int height, Texture2D centerIcon) {
            Texture2D texture = GenerateQRCodeWithIcon(content, width, height, centerIcon);
            Sprite sp = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.zero);
            return sp;
        }


        /// <summary> </summary>
        public Color32[] data;
        /// <summary>对是否开启扫描的判定 </summary>
        private bool isScan;
        /// <summary> 相机得到的图片映射显示UI</summary>
        public RawImage cameraTexture;
        /// <summary>二维码内容的文本框UI </summary>
        public Text txtQRcode;
        /// <summary>相机 </summary>
        private WebCamTexture webCameraTexture;
        /// <summary> </summary>
        private BarcodeReader barcodeReader;
        /// <summary> 扫描的间隔时间</summary>
        private float timer = 0;

        IEnumerator _OnEnable() {

            barcodeReader = new BarcodeReader();
            yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);
            if (Application.HasUserAuthorization(UserAuthorization.WebCam)) {
                WebCamDevice[] devices = WebCamTexture.devices;
                string devicename = devices[0].name;
                webCameraTexture = new WebCamTexture(devicename, 400, 300);
                cameraTexture.texture = webCameraTexture;
                webCameraTexture.Play();
                isScan = true;
                Debug.Log("已经找到了相机");
            }

            isScan = true;//扫描状态开启
            txtQRcode.text = "";//文本显示为空白
            webCameraTexture.Play();//开启相机功能


        }
        /// <summary>
        /// 扫码，扫描识别二维码
        /// </summary>
        /// <returns></returns>
        IEnumerator ScanQRcode() {
            data = webCameraTexture.GetPixels32();
            DecodeQR(webCameraTexture.width, webCameraTexture.height);
            yield return new WaitForEndOfFrame();
        }
        /// <summary>
        /// 解码二维码
        /// </summary>
        /// <param name="width"></param>
        /// <param name="height"></param>
        private void DecodeQR(int width, int height) {
            var br = barcodeReader.Decode(data, width, height);
            if (br != null) {
                txtQRcode.text = br.Text;//显示二维码解析内容
                isScan = false;//不再进行扫码判断
                webCameraTexture.Stop();//相机停止
                CheckCode(txtQRcode.text);//解析得到的二维码数据，进行核对做出动作
            }
        }
        /// <summary>
        /// 核对二维码做出处理
        /// </summary>
        /// <param name="QRscan"></param>
        private void CheckCode(string QRscan) {
            //如果解析的内容里面包含"_"， 区分是不是我们自己定义的二维码内容
            //如果内容是包含"_"，有可能是我们自己定义的二维码内容
            //如果不包含 不做处理
            if (QRscan.Contains("_")) {
                var str1 = QRscan.Split('_')[0];
                var str2 = QRscan.Split('_')[1];
                switch (str1) {
                    case "AddFriend":
                        break;
                    default:
                        //如果都不是关键字，说明不是我们自己定义的二维码，不做处理
                        //ErrorDisplay.Log(QRscan);
                        break;
                }
            }
        }

        #region 帮助方法
        /// <summary>
        /// 插入二维码到背景图中
        /// </summary>
        /// <param name="bgImage">背景图</param>
        /// <param name="qrCode">二维码</param>
        /// <param name="offsetX">二维码相对中心点的X方向偏移</param>
        /// <param name="offsetY">二维码相对中心点的Y方向偏移</param>
        /// <returns></returns>
        public static Texture2D MergeImage(Texture2D bgImage, Texture2D qrCode, int offsetX = 0, int offsetY = 0) {
            Texture2D texture2D = new Texture2D(bgImage.width, bgImage.height);

            Color32[] bgcolor = bgImage.GetPixels32();

            //写入背景
            int x = 0, y = 0;

            texture2D.SetPixels32(x, y, bgImage.width, bgImage.height, bgcolor);

            //写入二维码
            int startX = (bgImage.width - qrCode.width) / 2 + offsetX;
            int startY = (bgImage.height - qrCode.height) / 2 + offsetY;

            Color32[] qrcolor = qrCode.GetPixels32();

            texture2D.SetPixels32(startX, startY, qrCode.width, qrCode.height, qrcolor);

            texture2D.Apply();

            return texture2D;
        }

        /// <summary>
        /// 自定义白边宽度的二维码.
        /// </summary>
        private static BitMatrix UpdateBitMatrix(BitMatrix matrix, int margin) {
            int tempM = margin * 2;
            int[] rec = matrix.getEnclosingRectangle();
            int resWidth = rec[2] + tempM;
            int resHeight = rec[3] + tempM;
            BitMatrix resMatrix = new BitMatrix(resWidth, resHeight);
            resMatrix.clear();
            for (int i = margin; i < resWidth - margin; i++) {
                for (int j = margin; j < resHeight - margin; j++) {
                    if (matrix[i - margin + rec[0], j - margin + rec[1]]) {
                        resMatrix[i, j] = matrix[i - margin + rec[0], j - margin + rec[1]];
                    }
                }
            }
            return resMatrix;
        }

        /// <summary>
        /// 根据图片路径获取图片数据.
        /// </summary>
        public static byte[] ReadImageData(string imagePath) {
            FileStream fs = new FileStream(imagePath, FileMode.Open);
            byte[] byteData = new byte[fs.Length];
            fs.Read(byteData, 0, byteData.Length);
            fs.Close();
            return byteData;
        }


        /// <summary>
        /// 保存图片到本地
        /// </summary>
        /// <param name="imagePath"></param>
        public static void WriteImageData(string imagePath, Texture2D image) {
            FileStream fs = new FileStream(imagePath, FileMode.OpenOrCreate);
            byte[] byteData = image.EncodeToPNG();
            fs.Write(byteData, 0, byteData.Length);
            fs.Close();
        }

        #endregion

    }
}